%Andrew Logue - 9/12/19

function [out] = divFunc(input1, input2)
%divides input1 by input2, returns the result
x = input1 / input2;
%sets the result of the arithmetic above to the output - "dummy data"
out = x;
end