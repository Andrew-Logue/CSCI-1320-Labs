%Andrew Logue - 9/12/19

function [out] = addFunc(input1, input2)
%adds input 1 and input 2, then returns the sum
x = input1 + input2;
%sets the result of the arithmetic above to the output - "dummy data"
out = x;
end

