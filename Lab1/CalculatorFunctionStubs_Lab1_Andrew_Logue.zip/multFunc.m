%Andrew Logue - 9/12/19

function [out] = multFunc(input1, input2)
%multiplies input1 by input2, returns the product
x = input1 * input2;
%sets the result of the arithmetic above to the output - "dummy data"
out = x;
end