%Andrew Logue - 9/12/19

function [out] = subFunc(input1, input2)
%subtracts input1 by input2, returns the difference
x = input1 - input2;
%sets the result of the arithmetic above to the output - "dummy data"
out = x;
end