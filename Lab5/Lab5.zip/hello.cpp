//Andrew Logue 10/24/19
//Lab 5 Hello World! program

#include <iostream>
using namespace std;

int main() {
     cout << "Hello world!" << endl;
    return 0;
}
